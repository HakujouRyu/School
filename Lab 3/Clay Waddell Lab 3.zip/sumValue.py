print("Please enter values below")
x = int(input("x = "))
y = int(input("Y = "))
z = int(input("Z = "))
print("X = ", x)
print("Y = ", y)
print("Z = ", z)
avg = (x + y +z)/3
print("Average = ", avg)