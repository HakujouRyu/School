age = int(input("Please enter your age: "))
youth = "Youth is a wonderful thing. Enjoy"
default = "Age is a state of mind"
if age <= 21:
    print(youth)
print(default)
