radius = int(input("Please enter radius of your Cylinder:"))
length = int(input("Please enter the length of your Cylinder: "))
pi = 3.14
area = radius ** 2 * pi
volume = area * length
print("The area of your cylinder is: ", area)
print("The volume of your cylinder is: ", volume)